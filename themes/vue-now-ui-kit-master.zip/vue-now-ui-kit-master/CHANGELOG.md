# Change Log

## [1.1.1] 2020-07-01
- Update packages

## [1.1.0] 2019-02-12
- Update all packages and lint files
- Fix UI issues related to form group input
- Add missing polyfills for IE
- Add examples dropdown with links to landing, profile and login pages

## [1.0.0] 2018-08-24
### Stable Original Release
